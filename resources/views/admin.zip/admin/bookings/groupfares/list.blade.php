@extends('admin.layouts.dashboard')

@section('content')

    <!-- Main Content -->
    <div class="content">
        <!-- Topbar -->
        <div class="topbar">
            <h5>Dashboard</h5>
            <div>
                <i class="fa fa-bell me-3"></i>
                <i class="fa fa-user-circle"></i>
            </div>
        </div>

        <!-- Dashboard Content -->
        <div class="container-fluid mt-4">
         
 <div class="topbar">
      <h5>Form Example</h5>
    </div>
            <div class="card mt-4 shadow-sm border-0">
                 <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Routes Information</h5>
        <a href="{{ route('admin.route.create') }}" class="btn btn-primary btn-sm"><i class="fa fa-plus me-1"></i> Add New</a>
      </div>
                
      
      


                <div class="card-body">
                    <table id="example" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Booking Date</th>
                                <th>Modules</th>
                                
                                <th>Traveller</th>
                                <th>Email</th>
                                 <th>Booking Status</th>
                                  <th>Payment Status</th>
                                   <th>Total</th>
                                    <th>PNR</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($Booking as $Bookings)
<?php 
  

   $users=json_decode($Bookings['user_data']);
     
      
      ?>
 
      <tr>
         <td>{{ $Bookings['booking_ref_no'] }}</td>
        <td>{{ $Bookings['booking_date'] }}</td>
        <td>{{ $Bookings['supplier'] }}</td>
        <td>{{ $users->first_name.' '.$users->last_name }}</td>
        <td>{{ $users->email }}</td>
        <td>{{ $Bookings['booking_status'] }}</td>
<td>{{ $Bookings['payment_status'] }}</td>
<td>{{ $Bookings['price_original'] }}</td>

<td>  

<input type="text" class="form-control pnr-input" 
           data-id="{{ $Bookings['booking_ref_no'] }}" 
           value="{{ $Bookings['pnr'] }}">
    <small class="text-success d-none saved-msg">Saved</small>

</td>
        
        <td><a href="{{ route('admin.gfares.list', $Bookings['booking_ref_no']) }}" class="btn btn-primary">Edit</a></td>

      </tr>
    @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){

    function debounce(func, delay) {
        let timer;
        return function() {
            const context = this;
            const args = arguments;
            clearTimeout(timer);
            timer = setTimeout(() => func.apply(context, args), delay);
        }
    }

    $('.pnr-input').on('input', debounce(function(){
        var input = $(this);
        var pnr = input.val();
        var id = input.data('id');

        $.ajax({
            url: '{{ route("admin.booking.updatePnr") }}',
            type: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                id: id,
                pnr: pnr
            },
            success: function(response){
                if(response.success){
                    // show saved message briefly
                    var msg = input.siblings('.saved-msg');
                    msg.removeClass('d-none');
                    setTimeout(() => msg.addClass('d-none'), 1000);
                }
            },
            error: function(){
                console.log('Update failed');
            }
        });

    }, 500)); // wait 500ms after last keystroke
});
</script>
@endsection
