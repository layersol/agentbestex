@include('admin.layouts.dashboard-header')


        @include('admin.layouts.dashboard-sidebar')

     
                            @yield('content')
                        
    

@include('admin.layouts.dashboard-footer')