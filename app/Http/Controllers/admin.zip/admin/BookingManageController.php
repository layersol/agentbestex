<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\airlines;
use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\Passenger;
use App\Models\User;
use App\Models\Inquiry;
use Illuminate\Validation\Rules;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use App\Models\Routes;
use App\Models\GroupFlight;
use App\Models\Airline;
use App\Models\FlightsBooking;


class BookingManageController extends Controller
{


public function bookingList() {
       $Booking = FlightsBooking::with('user')->get();
       $Booking = json_decode($Booking, true);

    return view('admin.bookings.groupfares.list', compact('Booking'));
       
    }


    public function updatePnr(Request $request)
{
    // $request->validate([
    //     'id' => 'required|exists:flights_bookings,id',
    //     'pnr' => 'required|string|max:20'
    // ]);

    $booking = FlightsBooking::find($request->id);
    $booking->pnr = $request->pnr;
    $booking->save();

    return response()->json(['success' => true]);
}

    public function index() {
       $route = Routes::all();
       $routes = json_decode($route, true);
    return view('admin.routes.list', compact('routes'));
       
    }
    public function flightlist(int $id){
        // $route = Routes::find($id);
        // return view('admin/sellflights/list',compact('route'));
      $flights = \DB::table('groupflights')
    ->join('routes', 'groupflights.route_id', '=', 'routes.id')
    ->select('groupflights.*', 'routes.origin', 'routes.destination')
    ->where('groupflights.route_id', $id)  // filter by id
    ->first(); // use first() to get a single record

// Optional: convert to array
// $flightArray = json_decode(json_encode($flight), true);




// print_r($flights);

//  $flights = json_decode($flight, true);
    return view('admin.sellflights.list', compact('flights'));




    }

     public function create(int $id){
        $route = Routes::find($id);
        $airlines = Airline::all(); // fetch all airlines
    // return view('admin.sellflights.create', compact('$id'));

    return view('admin.sellflights.create', compact('route', 'airlines'));
    }

     public function edit(int $id){

        $flight = GroupFlight::find($id);
        $airlines = Airline::all(); // fetch all airlines
    // return view('admin.sellflights.create', compact('$id'));

    return view('admin.sellflights.create', compact('flight', 'airlines'));
    }
    
    


  public function storeOrUpdate(Request $request)
{


// print_r($request->all());

// exit;

    // Validate request
    // $request->validate([
    //     'route_id' => 'required|integer|exists:routes,id',
    //     'departure_airport' => 'required|string|max:255',
    //     'arrival_airport' => 'required|string|max:255',
    //     'departure_date' => 'required|date',
    //     'return_date' => 'required|date|after_or_equal:departure_date',
    //     'departure_time' => 'required',
    //     'arrival_time' => 'required',
    //     'airline_id' => 'required|integer|exists:airlines,id',
    //     'code' => 'required|string|max:10',
    //     'number' => 'required|string|max:10',
    //     'baggaes' => 'required|numeric|min:0',
    //     'seats' => 'required|integer|min:1',
    //     'adult_price' => 'required|numeric|min:0',
    //     'child_price' => 'required|numeric|min:0',
    //     'infant_price' => 'required|numeric|min:0',
    //     'currency' => 'required|string|max:5',
    //     'status' => 'required|in:active,inactive',
    // ]);

    // Check if flight ID exists to update, otherwise create new
    if ($request->has('id') && $request->id) {
        // Update existing flight
        $flight = GroupFlight::findOrFail($request->id);
        $flight->update($request->only([
            'departure_airport','arrival_airport','departure_date','return_date',
            'departure_time','arrival_time','airline_id','code','number','baggaes',
            'seats','adult_price','child_price','infant_price','currency','status'
        ]));
        $message = 'Flight updated successfully!';
    } else {
        // Create new flight
        $flight = GroupFlight::create($request->only([
            'route_id','departure_airport','arrival_airport','departure_date','return_date',
            'departure_time','arrival_time','airline_id','code','number','baggaes',
            'seats','adult_price','child_price','infant_price','currency','status'
        ]));
        $message = 'Flight created successfully!';
    }

    // Redirect to list page with success message
    return redirect()->route('admin.gfares.list', ['id' => $request->route_id])
                     ->with('success', $message);
}
 

    public function update(Request $request)
{


     $request->validate([
        'departure_airport' => 'required|string|max:255',
        'arrival_airport' => 'required|string|max:255',
        'departure_date' => 'required|date',
        'return_date' => 'required|date|after_or_equal:departure_date',
        'departure_time' => 'required',
        'arrival_time' => 'required',
        'airline_id' => 'required|integer|exists:airlines,id',
        'code' => 'required|string|max:10',
        'number' => 'required|string|max:10',
        'baggaes' => 'required|numeric|min:0',
        'seats' => 'required|integer|min:1',
        'adult_price' => 'required|numeric|min:0',
        'child_price' => 'required|numeric|min:0',
        'infant_price' => 'required|numeric|min:0',
        'currency' => 'required|string|max:5',
        'status' => 'required|in:active,inactive',
    ]);

    $flight = GroupFlight::findOrFail($request->id);

    $flight->update($request->only([
        'departure_airport','arrival_airport','departure_date','return_date',
        'departure_time','arrival_time','airline_id','code','number','baggaes',
        'seats','adult_price','child_price','infant_price','currency','status'
    ]));

    // return redirect()->route('admin.gfares.list', ['id' => $request['route_id']])
                    //  ->with('success', 'Flight updated successfully!');
}

    
    

    // public function viewTicket($id){
    //     $ticket=Ticket::with('passengers')->find($id);

    //     return view('backend/bookings/ticket-view',compact('ticket'));

    // }

    // public function editTicket($id){
    //     $ticket=Ticket::with('passengers')->findorfail($id);
    //     return view('backend/bookings/ticket-edit',compact('ticket'));
    // }

    // public function updatePassengers(Request $request, $id)
    // {
    //     $passengerData = $request->only(['title', 'name', 'surname']);
    //     $ticket=Ticket::find($id);
    //     foreach ($passengerData['title'] as $index => $title) {
    //         $passengerId = $request->input('passenger_ids')[$index];
    //         $ticket->passengers()->where('id', $passengerId)->update([
    //             'title' => $title,
    //             'name' => $passengerData['name'][$index],
    //             'surname' => $passengerData['surname'][$index],
    //         ]);
    //     }
    
    //     return redirect()->route('/booking-list')->with('success','Passengers data updated');

    // }

    // public function cancelbooking($id){
    //     $user=auth()->user();
    //     $ticket = Ticket::findOrFail($id);

    //     if (!($user->hasPermissionTo('manage all bookings') || $ticket->user_id === $user->id)) {
    //         return redirect()->back()->with('error', 'You are not authorized to  this .');
    //     }
       
    //     // Check if the ticket is already cancelled
    //     if ($ticket->ticket_status == 'cancelled') {
    //         return redirect()->route('/booking-list')->with('error', 'Ticket is already cancelled');
    //     }
    
    //     // Update the ticket status to 'cancelled'
    //     $ticket->ticket_status = 'cancelled';
    //     $ticket->save();
    
    //     return redirect()->route('/booking-list')->with('success', 'Booking cancelled');
    // }
    
    // public function bookingInquiry($id = null)
    // {
    //     // Get the authenticated user ID
    //     $authUserId = Auth::id();
    
    //     if ($id) {
    //         // Fetch the inquiry by ID with the 'viewedBy' relationship
    //         $inquiries = Inquiry::with('viewedBy')->find($id);
    
    //         if ($inquiries) {
    //             // Set the status to 'inactive'
    //             $inquiries->status = 'inactive';
    
    //             // Set the 'view_by' column to the authenticated user's ID
    //             $inquiries->view_by = $authUserId;
    
    //             // Save the changes
    //             $inquiries->save();
    //         }
    //         $query=$inquiries;
    //         return view('backend/bookings/inquiries/inquiry-single', compact('query'));
    //     } else {
    //         // Fetch all inquiries with the 'viewedBy' relationship
    //         $inquiries = Inquiry::with('viewedBy')->orderBy('created_at')->get();
    
    //         return view('backend/bookings/inquiries/inquiry-list', compact('inquiries'));
    //     }
    // }
    
    // public function bookingInquiryUpdate(Request $request,$id){
    //     $request->validate([
    //         'comment' => 'sometimes|string|nullable',
        
    //     ]);
    //     $inquiry=Inquiry::findOrfail($id);
    //     $inquiry->comment=$request->input('comment');
    //     $inquiry->view_by=Auth::id();
    //     $inquiry->save();
    //     return redirect()->route('booking-inquiry')->with('success','Inquiry Updated Successfully');
    // }
    
}
